#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include<stdlib.h>
#include<stdio.h>

struct bin_tree {
int data;
struct bin_tree * right, * left;
};
typedef struct bin_tree node;
void insert(node ** tree, int val)
{
    node *temp = NULL;
    if(!(*tree))
    {
        temp = (node *)malloc(sizeof(node));
        temp->left = temp->right = NULL;
        temp->data = val;
        *tree = temp;
        return;
    }

    if(val < (*tree)->data)
    {
        insert(&(*tree)->left, val);
    }
    else if(val > (*tree)->data)
    {
        insert(&(*tree)->right, val);
    }

}

void print_preorder(node * tree)
{
    if (tree)
    {
        printf("%d\n",tree->data);
        print_preorder(tree->left);
        print_preorder(tree->right);
    }

}

void print_inorder(node * tree)
{
    if (tree)
    {
        print_inorder(tree->left);
        printf("%d\n",tree->data);
        print_inorder(tree->right);
    }
}

void print_postorder(node * tree)
{
    if (tree)
    {
        print_postorder(tree->left);
        print_postorder(tree->right);
        printf("%d\n",tree->data);
    }
}

void deltree(node * tree)
{
    if (tree)
    {
        deltree(tree->left);
        deltree(tree->right);
        free(tree);
    }
}

node* search(node ** tree, int val)
{
    if(!(*tree))
    {
        return NULL;
    }

    if(val < (*tree)->data)
    {
        search(&((*tree)->left), val);
    }
    else if(val > (*tree)->data)
    {
        search(&((*tree)->right), val);
    }
    else if(val == (*tree)->data)
    {
        return *tree;
    }
}


int _tmain(int argc, _TCHAR* argv[])
{
    
    node *root;
    node *tmp;
    int i;
    

	bool grad, grad2;
	int SUM = 0;
	int sum = 0;
	int QuantityElements = 0;
	int  ii = 0;
	int i1 = 0;
	int j = 0;
	int	QuantityOfSum = 0;
	char message[50];
	char *PtrToMessage;
	int len=0;
	PtrToMessage = message;
	HANDLE Son;
	LPCSTR AdresNameFile = "\\\\.\\pipe\\MyPipe";
	Sleep (12);
	Son = CreateFile(AdresNameFile, GENERIC_READ | GENERIC_WRITE , 0, NULL, OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL, NULL);
	if (Son == INVALID_HANDLE_VALUE)
	{
		printf("I'm Son.\n Daddy doesn't createeeeeeeeee");
		getchar();
		printf("NNNNNNOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO");
		return GetLastError();
	};
	//bool connect = ConnectNamedPipe(Son, &l);
	/*if (connect == false)
	{

		int i = GetLastError();
		if (i == 997 || i == 536)
		{
		}
		else {
			return GetLastError();
		};
	};*/
	DWORD in;
	if (!ReadFile(Son, PtrToMessage,50, &in , NULL))
	/*{
		printf("I CAN'T READ FILE");
		return GetLastError();
	};*/
	/*Son = CreateFile(AdresNameFile, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, TRUNCATE_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (Son == INVALID_HANDLE_VALUE)
	{
		printf("Son doesn't open file");
		getchar();
		printf("NNNNNNOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO");
		ExitProcess(1);
		return 1;

	};*/
	if(*PtrToMessage==1)
	{
        printf("Enter elem\n");
        scanf("%d", i);
        insert(&root, i);
}                   
if(*PtrToMessage==2)
{
     printf("Pre Order Display\n");
    print_preorder(root);              
}
if(*PtrToMessage==3)
{
     printf("Post Order Display\n");
    print_postorder(root);              
}
if(*PtrToMessage==4)
{
     printf("In Order Display\n");
    print_inorder(root);              
}
if(*PtrToMessage==5)
{
     printf("Delete tree\n");
    deltree(root);              
}
if(*PtrToMessage==6)
{
     printf("Search node. Enter one\n");
     scanf("%d", i);
     tmp = search(&root, i);
    if (tmp)
    {
        printf("Searched node=%d\n", tmp->data);
    }
    else
    {
        printf("Data Not found in tree.\n");
    }
}
if(*PtrToMessage==7)
{
     printf("Exit\n");
    char Out[20];
	char *PtrToOut;
	PtrToOut = Out;
	wsprintf(PtrToOut, "%d", SUM);
	WriteFile(Son, PtrToOut, 15, 0, NULL);
	if (Son == INVALID_HANDLE_VALUE)
	{
		printf("Error! Can not write data in file\n");
		ExitProcess(1);
		return 1;
	};
	system("pause");
	Sleep(100);
	ExitProcess(1);
	return 0;              
}	
else
{printf("wrong choise");
}
};




LPCVOID Error(int i)
{
	LPCVOID Errors;
	if (i == 1)
	{
		Errors = TEXT("you bad write \n");
		return Errors;
	};
	return 0;
};





