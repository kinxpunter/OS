#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>
#ifdef _UNICODE
typedef wchar_t TCHAR;
#else
typedef char TCHAR;
#endif


int _tmain(int argc, _TCHAR* argv[])
{
    int PtrOnString=0;
while(PtrOnString!=7)
{
	printf("1. Add elem\n");
    printf("2. Pre-order\n");
   	printf("3. Post-order\n");
	printf("4. In-order\n");
	printf("5. Delete\n");
	printf("6. Search node\n");
	printf("7. Exit\n");
	printf("Enter choise: \n");
	scanf ("%d", PtrOnString);
	HANDLE Daddy;
	DWORD writeb,readb;
	LPCSTR AdresNameFile = ("\\\\.\\pipe\\MyPipe");
	//LPWSTR AdresNameFile =TEXT ("C:\\Users\\Arkadii\\Desktop\\OS\\Data.txt");
	Daddy = CreateNamedPipe(AdresNameFile, PIPE_ACCESS_DUPLEX,
		PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT,
		1, 128, 128,
		PIPE_UNLIMITED_INSTANCES,
		NULL);
	if (Daddy == INVALID_HANDLE_VALUE)
	{
		printf("Daddy's PIPE doesn't createeeeeeeeee");
		printf("  NNNNNNOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO");
		system("pause");
		return GetLastError();
	};

	PROCESS_INFORMATION ProcessInfo; //This is what we get as an [out] parameter
	ZeroMemory(&ProcessInfo, sizeof(PROCESS_INFORMATION));
	STARTUPINFO StartupInfo; //This is an [in] parameter
	ZeroMemory(&StartupInfo, sizeof(StartupInfo));
	StartupInfo.cb = sizeof(STARTUPINFO); //Only compulsory field
	bool process = CreateProcess("C:\\Users\\Arkadii\\Desktop\\codeblock\\��\\L2(client)\\bin\\Debug\\L2(client).exe", //NULL
		NULL,
		NULL, NULL, true,
		CREATE_NEW_CONSOLE,// CREATE_NEW_CONSOLE|CREATE_SUSPENDED
		NULL, NULL,
		&StartupInfo,
		&ProcessInfo);
	WaitForSingleObject(ProcessInfo.hProcess, 5);
	bool connect = ConnectNamedPipe(Daddy, NULL);
	if (connect == false)
	{

		int i = GetLastError();
		if (i == 997 || i == 536)
		{
		}
		else {
			return GetLastError();
		};
	};
	DWORD written;
	if (!WriteFile(Daddy, &PtrOnString,sizeof(int), &writeb, NULL))
	{
		printf("Error! Can not write in file\n");
		system("pause");
		return GetLastError();
	};
	WaitForSingleObject(ProcessInfo.hProcess,2);
	if (!ReadFile(Daddy,&PtrOnString,sizeof(int),&readb, NULL))
	{
		printf(" i can't read file\n");
		system("pause");	
        CloseHandle(Daddy);
		return GetLastError();
	};
	CloseHandle(Daddy);
	printf("\nAnswer = %s\n", PtrOnString);
	system("pause");
}
	return 0;
}
